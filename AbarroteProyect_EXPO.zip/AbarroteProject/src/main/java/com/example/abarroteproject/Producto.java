package com.example.abarroteproject;

import javafx.beans.property.SimpleStringProperty;

public class Producto {
    String nombre;
    Double precio;
    String id;
    public SimpleStringProperty nom = new SimpleStringProperty();

    public Producto(String id, String nombre, Double precio) {
        this.nombre = nombre;
        this.precio = precio;
        this.id = id;
    }


    public String getNom() {
        return nom.get();
    }

    public String getNombre() {
        return nombre;
    }

    public Double getPrecio() {
        return precio;
    }

    public String getId() {
        return id;
    }
}
