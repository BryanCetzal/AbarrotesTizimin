package com.example.abarroteproject;


import javafx.application.Platform;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PagoController {
    @FXML
    private Label totalfin;

    @FXML
    private VBox ticket;
    @FXML
    private Label lblCambio;
    @FXML
    private TextField txtDineroProp;


    @FXML
    void FinalizarCompra(MouseEvent event) {
        ticket.setVisible(true);
    }
    @FXML
    void Confirmar(MouseEvent event) {
        float totalpagar = Float.parseFloat(totalfin.getText());
        float dineroprop = Float.parseFloat(txtDineroProp.getText());

        float cambio = dineroprop - totalpagar;
        lblCambio.setText(String.valueOf(cambio));
    }

    private void loadStage(String url, Event event){
        try {
            ((Node)(event.getSource())).getScene().getWindow().hide();

            FXMLLoader loader = new FXMLLoader(getClass().getResource("tienda.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage newStage = new Stage();
            newStage.setScene(scene);
            newStage.show();

            newStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
                @Override
                public void handle(WindowEvent event) {
                    Platform.exit();
                }
            });
        } catch (IOException ex) {
        Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private float total;
    public void setTotal(float total) {
        this.total = total;
        totalfin.setText(String.valueOf(total));
    }

    @FXML
    void volverTienda(MouseEvent event){
        Object evt = event.getSource();
        loadStage("principal.fxml", event);

    }
}
