package com.example.abarroteproject;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class Cliente {
    public SimpleStringProperty nombre = new SimpleStringProperty();
    public SimpleStringProperty apellido = new SimpleStringProperty();
    public SimpleIntegerProperty telefono = new SimpleIntegerProperty();
    public SimpleStringProperty calle = new SimpleStringProperty();
    public SimpleIntegerProperty id = new SimpleIntegerProperty();
    public SimpleStringProperty cruz1 = new SimpleStringProperty();
    public SimpleStringProperty cruz2 = new SimpleStringProperty();
    public SimpleStringProperty numExt = new SimpleStringProperty();
    public SimpleIntegerProperty cp = new SimpleIntegerProperty();
    public SimpleStringProperty ciudad = new SimpleStringProperty();
    public SimpleStringProperty colonia = new SimpleStringProperty();
    public SimpleStringProperty estado = new SimpleStringProperty();
    public SimpleStringProperty ref = new SimpleStringProperty();

    public String getNombre() {
        return nombre.get();
    }

    public String getApellido() {
        return apellido.get();
    }

    public int getTelefono() {
        return telefono.get();
    }

    public String getCalle() {
        return calle.get();
    }


    public int getId() {
        return id.get();
    }
    public String getCruz1() {
        return cruz1.get();
    }

    public String getCruz2() {
        return cruz2.get();
    }

    public String getNumExt() {
        return numExt.get();
    }

    public int getCp() {
        return cp.get();
    }

    public String getCiudad() {
        return ciudad.get();
    }

    public String getColonia() {
        return colonia.get();
    }

    public String getEstado() {
        return estado.get();
    }

    public String getRef() {
        return ref.get();
    }
}
