package com.example.abarroteproject;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TiendaController implements Initializable {
    @FXML
    private Label Ncliente;

    @FXML
    private Label IdCliente;
    @FXML
    private Button btnBorrarSelec;

    @FXML
    private TableView<Producto> tablaProductos;

    @FXML
    private TableColumn<Producto, String> IdCL;

    @FXML
    private TableColumn<Producto, String> nombreCL;

    @FXML
    private TableColumn<Producto, Double> precioCL;

    @FXML
    private TextField txtFiltrarNombre;

    @FXML
    private TableView<Producto> tablaCarrito;

    @FXML
    private TableColumn<Producto, String> productoCL;

    @FXML
    private TableColumn<Producto, Double>  precioCL2;

    @FXML
    private Button btnConfirmar;

    @FXML
    private Label lblTotal;

    private int posicionProductoTabla;

    ObservableList<Producto> listaProducto = FXCollections.observableArrayList(
            new Producto("p101", "Coca 1 L", 25.00),
            new Producto("p102", "Coca 500 ml", 18.00),
            new Producto("p103", "Pepsi 1 L", 25.00),
            new Producto("p104", "Pepsi 500 ml", 18.00),
            new Producto("p105", "Doritos medianos", 16.00),
            new Producto("p106", "Emperador", 19.00),
            new Producto("p107", "Sopa Nissin", 20.00),
            new Producto("p108", "Bizcochitos medianos", 22.00),
            new Producto("p109", "Bizcochitos Grandes", 22.00),
            new Producto("p110", "Powerade Mora", 28.00),
            new Producto("p111", "Cheetos Flamin Hot", 14.00),
            new Producto("p112", "Baygon grande", 30.00),
            new Producto("p113", "Rollo de Papel Suavel", 25.00),
            new Producto("p114", "Baterías triple A", 30.00),
            new Producto("p115", "Desodorante Obao pequeño", 28.00),
            new Producto("p116", "Colgate", 25.00),
            new Producto("p117", "Salchicha", 3.5),
            new Producto("p118", "Huevo", 2.5),
            new Producto("p119", "Aceite 1 L", 36.00),
            new Producto("p120", "Aceite 500 ml", 19.00),
            new Producto("p121", "Pan Integral", 20.00),
            new Producto("p122", "Charritos grandes", 30.00),
            new Producto("p123", "Café mediano", 20.00)

    );
    ObservableList<Producto> filtroProducto;

    @FXML
    private void filtrarNombre(KeyEvent event){

        String filtroNombre = this.txtFiltrarNombre.getText();
        if(filtroNombre.isEmpty()){
            this.tablaProductos.setItems(listaProducto);
        }else{
            this.filtroProducto.clear();
            for(Producto p: listaProducto){
                if (p.getNombre().toLowerCase().contains(filtroNombre.toLowerCase())) {
                    this.filtroProducto.add(p);
                }
             }
            this.tablaProductos.setItems(filtroProducto);
        }

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        IdCL.setCellValueFactory(new PropertyValueFactory<Producto, String>("id"));
        nombreCL.setCellValueFactory(new PropertyValueFactory<Producto, String>("nombre"));
        precioCL.setCellValueFactory(new PropertyValueFactory<Producto, Double>("precio"));

        productoCL.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        precioCL2.setCellValueFactory(new PropertyValueFactory<>("precio"));

        tablaProductos.setItems(listaProducto);
        filtroProducto = FXCollections.observableArrayList();

        tablaProductos.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                Producto productoDestino = new Producto(newValue.getId(), newValue.getNombre(), newValue.getPrecio());

                // Agregar el elemento seleccionado a la tabla de destino
                tablaCarrito.getItems().add(productoDestino);
            }
        });
        btnBorrarSelec.setOnAction(event -> {
            // Obtener la lista de elementos seleccionados en la tabla de destino
            ObservableList<Producto> productosSeleccionados = tablaCarrito.getSelectionModel().getSelectedItems();

            // Eliminar los elementos seleccionados de la tabla de destino
            tablaCarrito.getItems().removeAll(productosSeleccionados);
        });

        btnConfirmar.setOnAction(event -> {
            // Obtener la lista de elementos en la tabla de destino
            ObservableList<Producto> productosDestino = tablaCarrito.getItems();

            // Variable para almacenar la suma de los precios
            double total = 0.0;

            // Calcular la suma de los precios de los productos
            for (Producto producto : productosDestino) {
                total += producto.getPrecio();
            }

            // Establecer el resultado en el Label
            lblTotal.setText(String.format("%.2f", total));
        });

    }

    @FXML
    private void volverPrincipal(MouseEvent event) {
        ((Node)(event.getSource())).getScene().getWindow().hide();
    }

    private void loadStage(String url, Event event){
        try {
            ((Node)(event.getSource())).getScene().getWindow().hide();


            //Parent root = FXMLLoader.load(getClass().getResource("principal.fxml"));
            FXMLLoader loader = new FXMLLoader(getClass().getResource("pago.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage newStage = new Stage();
            newStage.setScene(scene);
            newStage.show();

            PagoController tot = loader.getController();
            tot.setTotal(getTotal());

            newStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
                @Override
                public void handle(WindowEvent event) {
                    Platform.exit();
                }
            });

        } catch (IOException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    void Pagar(MouseEvent event) {
        Object evt = event.getSource();
        loadStage("pago.fxml", event);
    }

    private String NOMcliente;
    private Integer IDcliente;
    public void setDatosCliente(String NOMcliente, Integer IDcliente) {
        this.NOMcliente = NOMcliente;
        this.IDcliente = IDcliente;

        Ncliente.setText(NOMcliente);
        IdCliente.setText(String.valueOf(IDcliente));
    }

    public float getTotal() {
        float total = Float.parseFloat(lblTotal.getText());
        return total;
    }
}
