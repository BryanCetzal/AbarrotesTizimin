package com.example.abarroteproject;

import javafx.application.Platform;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.stage.WindowEvent;
import javax.swing.*;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PrincipalController implements Initializable {

    @FXML
    private HBox Error;
    @FXML
    private Label NUsuario;
    @FXML
    private Label idTXT;

    //Botones de interacción
    @FXML
    private Button nuevoBT;
    @FXML
    private Button agregarBT;
    @FXML
    private Button editarBT;
    @FXML
    private Button borrarBT;

    //Columnas de la tabla
    @FXML
    private TableView<Cliente> tablaClientes;
    @FXML
    private TableColumn idCL;
    @FXML
    private TableColumn nombreCL;
    @FXML
    private TableColumn apellidosCL;
    @FXML
    private TableColumn telCL;
    @FXML
    private TableColumn calleCL;
    @FXML
    private TableColumn cruz1CL;
    @FXML
    private TableColumn cruz2CL;
    @FXML
    private TableColumn numExtCL;
    @FXML
    private TableColumn cpCL;
    @FXML
    private TableColumn coloniaCL;
    @FXML
    private TableColumn ciudadCL;
    @FXML
    private TableColumn estadoCL;
    @FXML
    private TableColumn refCL;

    //Casillas de texto
    @FXML
    private TextField nombreTXT;
    @FXML
    private TextField apellidosTXT;
    @FXML
    private TextField telTXT;
    @FXML
    private TextField calleTXT;
    @FXML
    private TextField cruz1TXT;
    @FXML
    private TextField cruz2TXT;
    @FXML
    private TextField numExtTXT;
    @FXML
    private TextField cpTXT;
    @FXML
    private TextField ciudadTXT;
    @FXML
    private TextField colTXT;
    @FXML
    private TextField estadoTXT;
    @FXML
    private TextField refTXT;

    ObservableList<Cliente> clienteList;

    private int posicionClienteTabla;


    @FXML
    void nuevo(MouseEvent event) {
        nombreTXT.setText("");
        apellidosTXT.setText("");
        telTXT.setText("");
        calleTXT.setText("");
        cruz1TXT.setText("");
        cruz2TXT.setText("");
        numExtTXT.setText("");
        cpTXT.setText("");
        ciudadTXT.setText("");
        colTXT.setText("");
        estadoTXT.setText("");
        refTXT.setText("");
        idTXT.setText("");

        editarBT.setDisable(true);
        borrarBT.setDisable(true);
        agregarBT.setDisable(false);
    }
    int push = 1000;
    @FXML
    void agregar(MouseEvent event) {
        try {
            push = push + 1;

            Cliente cl = new Cliente();
            cl.nombre.set(nombreTXT.getText());
            cl.apellido.set(apellidosTXT.getText());
            cl.telefono.set(Integer.parseInt(telTXT.getText()));
            cl.calle.set(calleTXT.getText());
            cl.cruz1.set(cruz1TXT.getText());
            cl.cruz2.set(cruz2TXT.getText());
            cl.numExt.set(numExtTXT.getText());
            cl.cp.set(Integer.parseInt(cpTXT.getText()));
            cl.ciudad.set(ciudadTXT.getText());
            cl.colonia.set(colTXT.getText());
            cl.estado.set(estadoTXT.getText());
            cl.ref.set(refTXT.getText());
            cl.id.setValue(push);

            Error.setVisible(false);
            clienteList.add(cl);
        }catch(java.lang.RuntimeException e){
            Error.setVisible(true);
        }
    }


    @FXML
    void borrar(MouseEvent event){
        try {
            clienteList.remove(posicionClienteTabla);

        }catch (java.lang.RuntimeException e){
            JOptionPane.showMessageDialog(null, "No se encontraron registros.", "Advertencia", JOptionPane.WARNING_MESSAGE);
        }
    }


    @FXML
    void editar(MouseEvent event) {
        try {
            Cliente cl = new Cliente();
            cl.nombre.set(nombreTXT.getText());
            cl.apellido.set(apellidosTXT.getText());
            cl.telefono.set(Integer.parseInt(telTXT.getText()));
            cl.calle.set(calleTXT.getText());
            cl.cruz1.set(cruz1TXT.getText());
            cl.cruz2.set(cruz2TXT.getText());
            cl.numExt.set(numExtTXT.getText());
            cl.cp.set(Integer.parseInt(cpTXT.getText()));
            cl.ciudad.set(ciudadTXT.getText());
            cl.colonia.set(colTXT.getText());
            cl.estado.set(estadoTXT.getText());
            cl.ref.set(refTXT.getText());
            cl.id.setValue(Integer.parseInt(idTXT.getText()));

            clienteList.set(posicionClienteTabla, cl);

        }catch (java.lang.RuntimeException e){
            JOptionPane.showMessageDialog(null, "No se encontraron registros.", "Advertencia", JOptionPane.WARNING_MESSAGE);
        }
    }

    private String Nusuario;

    public void setUsuario(String Nusuario) {
        this.Nusuario = Nusuario;
        NUsuario.setText(Nusuario);
    }

    //Seleccionar una celda en la tabla
    private final ListChangeListener<Cliente> selectorTablaClientes = new ListChangeListener<Cliente>() {
        @Override
        public void onChanged(ListChangeListener.Change<? extends Cliente> c) {
            ponerClienteSeleccionado();
        }
    };
    public Cliente getTablaClientesSeleccionado(){
        if(tablaClientes != null){
            List<Cliente> tabla = tablaClientes.getSelectionModel().getSelectedItems();
            if (tabla.size() == 1){
                final Cliente competicionSeleccionada = tabla.get(0);
                return competicionSeleccionada;
            }
        }
        return null;
    }
    public boolean bandera;
    private void ponerClienteSeleccionado(){
        final Cliente cliente = getTablaClientesSeleccionado();
        posicionClienteTabla = clienteList.indexOf(cliente);

        if(cliente != null){
            //Pongo los textFields con los datos correspondientes
            nombreTXT.setText(cliente.getNombre());
            apellidosTXT.setText(cliente.getApellido());
            telTXT.setText(String.valueOf(cliente.getTelefono()));
            calleTXT.setText(cliente.getCalle());
            cruz1TXT.setText(cliente.getCruz1());
            cruz2TXT.setText(cliente.getCruz2());
            numExtTXT.setText(cliente.getNumExt());
            cpTXT.setText(String.valueOf(cliente.getCp()));
            ciudadTXT.setText(cliente.getCiudad());
            colTXT.setText(cliente.getColonia());
            estadoTXT.setText(cliente.getEstado());
            refTXT.setText(cliente.getRef());
            idTXT.setText(String.valueOf(cliente.getId()));

            //Pongo los botones en su estado correspondiente
            editarBT.setDisable(false);
            borrarBT.setDisable(false);
            agregarBT.setDisable(false);
            bandera = false;
        }else{
            bandera = true;
        }
    }

    //Iniciarlizar la tabla
    private void inicializarClientes(){
        nombreCL.setCellValueFactory(new PropertyValueFactory<Cliente,String>("nombre"));
        apellidosCL.setCellValueFactory(new PropertyValueFactory<Cliente,String>("apellido"));
        telCL.setCellValueFactory(new PropertyValueFactory<Cliente,Integer>("telefono"));
        calleCL.setCellValueFactory(new PropertyValueFactory<Cliente,String>("calle"));
        cruz1CL.setCellValueFactory(new PropertyValueFactory<Cliente,String>("cruz1"));
        cruz2CL.setCellValueFactory(new PropertyValueFactory<Cliente,String>("cruz2"));
        numExtCL.setCellValueFactory(new PropertyValueFactory<Cliente,String>("numExt"));
        cpCL.setCellValueFactory(new PropertyValueFactory<Cliente,Integer>("cp"));
        ciudadCL.setCellValueFactory(new PropertyValueFactory<Cliente,String>("ciudad"));
        coloniaCL.setCellValueFactory(new PropertyValueFactory<Cliente,String>("colonia"));
        estadoCL.setCellValueFactory(new PropertyValueFactory<Cliente,String>("estado"));
        refCL.setCellValueFactory(new PropertyValueFactory<Cliente,String>("ref"));
        idCL.setCellValueFactory(new PropertyValueFactory<Cliente,Integer>("id"));

        clienteList = FXCollections.observableArrayList();
        tablaClientes.setItems(clienteList);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb){
        this.inicializarClientes();

        editarBT.setDisable(true);
        borrarBT.setDisable(true);

        //Seleccionar las tuplas de la tabla de clientes
        final ObservableList<Cliente> tablaClientesel = tablaClientes.getSelectionModel().getSelectedItems();
        tablaClientesel.addListener(selectorTablaClientes);
    }

    //Volver al Login
    @FXML
    void volverLogin(MouseEvent event) {
        Object evt = event.getSource();
            loadStage("principal.fxml", event);
    }

    private void loadStage(String url, Event event){
        try {
            ((Node)(event.getSource())).getScene().getWindow().hide();


            //Parent root = FXMLLoader.load(getClass().getResource("principal.fxml"));
            FXMLLoader loader = new FXMLLoader(getClass().getResource("login.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage newStage = new Stage();
            newStage.setScene(scene);
            newStage.show();

            newStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
                @Override
                public void handle(WindowEvent event) {
                    Platform.exit();
                }
            });

        } catch (IOException ex) {
            Logger.getLogger(PrincipalController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //Ir de compras
    @FXML
    void deCompras(MouseEvent event) {
        final Cliente cliente = getTablaClientesSeleccionado();
        posicionClienteTabla = clienteList.indexOf(cliente);

        if(cliente != null){
            Object evt = event.getSource();
            loadStage2("tienda.fxml", event);
        }else{
            JOptionPane.showMessageDialog(null, "Seleccione un cliente para poder continuar.", "Advertencia", JOptionPane.WARNING_MESSAGE);

        }

    }

    public String getDatosCliente(){
        final Cliente cliente = getTablaClientesSeleccionado();
        posicionClienteTabla = clienteList.indexOf(cliente);
        if(cliente != null){
            String NOMcliente = cliente.getNombre();
            return NOMcliente;
        }
        return null;
    }

    public Integer getIdCliente(){
        final Cliente cliente = getTablaClientesSeleccionado();
        posicionClienteTabla = clienteList.indexOf(cliente);

        Integer IDcliente = Integer.valueOf(cliente.getId());
        return IDcliente;
    }

    private void loadStage2(String url, Event event){
        try {
            ((Node)(event.getSource())).getScene().getWindow();


            //Parent root = FXMLLoader.load(getClass().getResource("principal.fxml"));
            FXMLLoader loader = new FXMLLoader(getClass().getResource("tienda.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage newStage = new Stage();
            newStage.setScene(scene);
            newStage.show();

            TiendaController us = loader.getController();
            us.setDatosCliente(getDatosCliente(), getIdCliente());

            newStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
                @Override
                public void handle(WindowEvent event) {
                    Platform.exit();
                }
            });

        } catch (IOException ex) {
            Logger.getLogger(PrincipalController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}