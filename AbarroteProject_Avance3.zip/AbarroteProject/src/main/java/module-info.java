module com.example.abarroteproject {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    requires java.sql;
    requires commons.dbcp2;
    requires java.management;


    opens com.example.abarroteproject to javafx.fxml;
    exports com.example.abarroteproject;
}