package com.example.abarroteproject;

import javax.swing.JOptionPane;
import javafx.application.Platform;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.stage.WindowEvent;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LoginController {
    @FXML
    public TextField txtUser;

    @FXML
    private PasswordField txtPassword;

    @FXML
    private Button btnLogin;



    @FXML
    private void eventKey(KeyEvent event) {
        Object evt = event.getSource();
        if(evt.equals(txtUser)){
            if(event.getCharacter().equals(" ")){
                event.consume();
            }

        }else if (evt.equals(txtPassword)){
            if(event.getCharacter().equals(" ")){
                event.consume();
            }
        }
    }

    @FXML
    void eventAction(MouseEvent event) {
        Object evt = event.getSource();
        if(evt.equals(btnLogin)){
            if(!txtUser.getText().isEmpty() && !txtPassword.getText().isEmpty()){
                getUsername();
                JOptionPane.showMessageDialog(null, "Inicio de sesión exitoso.");
                loadStage("principal.fxml", event);
            } else {
                JOptionPane.showMessageDialog(null, "Datos incorrectos.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    public String getUsername(){
        String Nusuario = txtUser.getText();
        return Nusuario;
    }



    private void loadStage(String url, Event event){
        try {
            //((Node)(event.getSource())).getScene().getWindow().hide();
            Object eventSource = event.getSource();
            Node sourceAsNode = (Node) eventSource ;
            Scene oldScene = sourceAsNode.getScene();
            Window window = oldScene.getWindow();
            Stage stage = (Stage) window ;
            stage.hide();

            //Parent root = FXMLLoader.load(getClass().getResource("principal.fxml"));
            FXMLLoader loader = new FXMLLoader(getClass().getResource("principal.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage newStage = new Stage();
            newStage.setScene(scene);
            newStage.show();

            PrincipalController us = loader.getController();
            us.setUsuario(getUsername());

            newStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
                @Override
                public void handle(WindowEvent event) {
                    Platform.exit();
                }
            });

        } catch (IOException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }


}