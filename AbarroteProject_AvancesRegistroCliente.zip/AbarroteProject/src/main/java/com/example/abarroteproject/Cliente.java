package com.example.abarroteproject;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class Cliente {
    public SimpleStringProperty nombre = new SimpleStringProperty();
    public SimpleStringProperty apellido = new SimpleStringProperty();
    public SimpleIntegerProperty telefono = new SimpleIntegerProperty();
    public SimpleStringProperty correo = new SimpleStringProperty();
    public SimpleIntegerProperty id = new SimpleIntegerProperty();

    public String getNombre() {
        return nombre.get();
    }

    public String getApellido() {
        return apellido.get();
    }

    public int getTelefono() {
        return telefono.get();
    }

    public String getCorreo() {
        return correo.get();
    }


    public int getId() {
        return id.get();
    }

}
