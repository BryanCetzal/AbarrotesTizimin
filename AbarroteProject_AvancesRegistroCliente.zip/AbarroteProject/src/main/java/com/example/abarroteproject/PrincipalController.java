package com.example.abarroteproject;

import javafx.application.Platform;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.stage.WindowEvent;

import javax.swing.*;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PrincipalController implements Initializable {


    @FXML
    private Label NUsuario;

    @FXML
    private Button nuevoBT;
    @FXML
    private Button agregarBT;
    @FXML
    private Button editarBT;
    @FXML
    private Button borrarBT;

    @FXML
    private TableView<Cliente> tablaClientes;
    @FXML
    private TableColumn idCL;
    @FXML
    private TableColumn nombreCL;
    @FXML
    private TableColumn apellidosCL;
    @FXML
    private TableColumn telCL;
    @FXML
    private TableColumn correoCL;

    @FXML
    private TextField nombreTXT;
    @FXML
    private TextField apellidosTXT;
    @FXML
    private TextField telTXT;
    @FXML
    private TextField correoTXT;

    ObservableList<Cliente> clienteList;

    private int posicionClienteTabla;

    @FXML
    void nuevo(MouseEvent event) {
        nombreTXT.setText("");
        apellidosTXT.setText("");
        telTXT.setText("");
        correoTXT.setText("");

        editarBT.setDisable(true);
        borrarBT.setDisable(true);
        agregarBT.setDisable(false);
    }

    @FXML
    void agregar(MouseEvent event) {
        Cliente cl = new Cliente();
        cl.nombre.set(nombreTXT.getText());
        cl.apellido.set(apellidosTXT.getText());
        cl.telefono.set(Integer.parseInt(telTXT.getText()));
        cl.correo.set(correoTXT.getText());
        clienteList.add(cl);


    }


    @FXML
    void borrar (MouseEvent event){
        try {
            clienteList.remove(posicionClienteTabla);
        }catch (java.lang.RuntimeException e){
            JOptionPane.showMessageDialog(null, "No se encontraron registros.");
        }
    }


    @FXML
    void editar(MouseEvent event) {
        try {
            Cliente cl = new Cliente();
            cl.nombre.set(nombreTXT.getText());
            cl.apellido.set(apellidosTXT.getText());
            cl.telefono.set(Integer.parseInt(telTXT.getText()));
            cl.correo.set(correoTXT.getText());
            clienteList.set(posicionClienteTabla, cl);
        }catch (java.lang.RuntimeException e){
            JOptionPane.showMessageDialog(null, "No se encontraron registros.");
        }
    }

    private String Nusuario;

    public void setUsuario(String Nusuario) {
        this.Nusuario = Nusuario;
        NUsuario.setText(Nusuario);
    }

    //Seleccionar una celda en la tabla
    private final ListChangeListener<Cliente> selectorTablaClientes = new ListChangeListener<Cliente>() {
        @Override
        public void onChanged(ListChangeListener.Change<? extends Cliente> c) {
            ponerClienteSeleccionado();
        }
    };
    public Cliente getTablaClientesSeleccionado(){
        if(tablaClientes != null){
            List<Cliente> tabla = tablaClientes.getSelectionModel().getSelectedItems();
            if (tabla.size() == 1){
                final Cliente competicionSeleccionada = tabla.get(0);
                return competicionSeleccionada;
            }
        }
        return null;
    }
    private void ponerClienteSeleccionado(){
        final Cliente cliente = getTablaClientesSeleccionado();
        posicionClienteTabla = clienteList.indexOf(cliente);

        if(cliente != null){
            //Pongo los textFields con los datos correspondientes
            nombreTXT.setText(cliente.getNombre());
            apellidosTXT.setText(cliente.getApellido());
            telTXT.setText(String.valueOf(cliente.getTelefono()));
            correoTXT.setText(cliente.getCorreo());

            //Pongo los botones en su estado correspondiente
            editarBT.setDisable(false);
            borrarBT.setDisable(false);
            agregarBT.setDisable(true);
        }
    }

    //Iniciarlizar la tabla
    private void inicializarClientes(){
        nombreCL.setCellValueFactory(new PropertyValueFactory<Cliente,String>("nombre"));
        apellidosCL.setCellValueFactory(new PropertyValueFactory<Cliente,String>("apellido"));
        telCL.setCellValueFactory(new PropertyValueFactory<Cliente,Integer>("telefono"));
        correoCL.setCellValueFactory(new PropertyValueFactory<Cliente,String>("correo"));
        //idCL.setCellValueFactory(new PropertyValueFactory<Cliente,Integer>("id"));

        clienteList = FXCollections.observableArrayList();
        tablaClientes.setItems(clienteList);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb){
        this.inicializarClientes();

        editarBT.setDisable(true);
        borrarBT.setDisable(true);

        //Seleccionar las tuplas de la tabla de clientes
        final ObservableList<Cliente> tablaClientesel = tablaClientes.getSelectionModel().getSelectedItems();
        tablaClientesel.addListener(selectorTablaClientes);
    }

    //Volver al Login
    @FXML
    void volverLogin(MouseEvent event) {
        Object evt = event.getSource();
            loadStage("principal.fxml", event);
    }

    private void loadStage(String url, Event event){
        try {
            ((Node)(event.getSource())).getScene().getWindow().hide();


            //Parent root = FXMLLoader.load(getClass().getResource("principal.fxml"));
            FXMLLoader loader = new FXMLLoader(getClass().getResource("login.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage newStage = new Stage();
            newStage.setScene(scene);
            newStage.show();

            newStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
                @Override
                public void handle(WindowEvent event) {
                    Platform.exit();
                }
            });

        } catch (IOException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}